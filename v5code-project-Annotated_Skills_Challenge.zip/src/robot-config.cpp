#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor leftMotorA = motor(PORT20, ratio18_1, false);
motor leftMotorB = motor(PORT7, ratio18_1, false);
motor_group LeftDriveSmart = motor_group(leftMotorA, leftMotorB);
motor rightMotorA = motor(PORT8, ratio18_1, true);
motor rightMotorB = motor(PORT10, ratio18_1, true);
motor_group RightDriveSmart = motor_group(rightMotorA, rightMotorB);
drivetrain Drivetrain = drivetrain(LeftDriveSmart, RightDriveSmart, 319.19, 387.34999999999997, 165.1, mm, 1);
motor Propeller1 = motor(PORT6, ratio18_1, true);
motor Propeller2 = motor(PORT1, ratio18_1, false);
motor Intake1 = motor(PORT19, ratio18_1, false);
motor Intake2 = motor(PORT18, ratio18_1, true);
controller Controller1 = controller(primary);
/*vex-vision-config:begin*/
signature Vision12__RBALL = signature (1, 4643, 11265, 7954, -1479, 391, -544, 1.9, 0);
signature Vision12__BBALL = signature (2, -3405, 1, -1702, -1, 8435, 4217, 0.5, 0);
signature Vision12__SIG_7 = signature (7, 0, 0, 0, 0, 0, 0, 11, 0);
vision Vision12 = vision (PORT12, 50, Vision12__RBALL, Vision12__BBALL, Vision12__SIG_7);
/*vex-vision-config:end*/

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}