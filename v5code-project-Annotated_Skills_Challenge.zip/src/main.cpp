/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Saanvi Agarwal and Asilah Maryam                          */
/*    Created:      Wed Sep 25 2020                                           */
/*    Description:  Coding and All Its Errors                                 */
/*       A unique composition in which all the conventions of code are
        observed, yet nothing seems to go according to what the code
        says due to external input. We envisioned a much more effective 
        and longer code, yet this was our output.                             */

/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    20, 7, 8, 10    
// Propeller1           motor         6               
// Propeller2           motor         1               
// Intake1              motor         19              
// Intake2              motor         18              
// Controller1          controller                    
// Vision12             vision        12              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
int p = 6;
// p is the ideal value for the propellor to intake the ball into the propellor
// system

int i = 4;
// i is the shortest value needed to intake the ball

int y = 8;
// y is the ideal number of turns for the propellor system to shoot out the
// balls

int full = 100;
//full speed in terms of percent

int slower = 60;
//this slower speed is for the drivetrain or else it will lurch due to the 
// weight of the intakes

void Preset() {
  Drivetrain.setDriveVelocity(slower, percent);
  Drivetrain.setTurnVelocity(slower, percent);
  // the drivetrain has a lower velocity
  Intake1.setVelocity(full, percent);
  Intake2.setVelocity(full, percent);
  Propeller1.setVelocity(full, percent);
  Propeller2.setVelocity(full, percent);
  // intakes and propellers have a high velocity to better intake and shoot the
  // ball
  Intake1.rotateFor(3, turns, false);
  Intake2.rotateFor(3, turns, true);
  // the false and true statements cause the intakes will spin together
  // these rotations cause the intakes to drop down from their folded position
}

void Intake() {
  Intake1.rotateFor(i, turns, false);
  Intake2.rotateFor(i, turns, false);
  Propeller1.rotateFor(p, turns, true);
  // the false and true statements cause the intakes will spin together
}
// this function will intake the ball and allow it to enter the propellor system 

void Shoot() {
  Propeller1.rotateFor(y, turns, false);
  Propeller2.rotateFor(y, turns, true);
}
// this function causes both the propellers to rotate to shoot out the ball

void check() {
  Vision12.takeSnapshot(Vision12__RBALL);
  if (Vision12.objects[0].exists) {
  // if the vision sensor senses red 
    Intake();
    // it will intake the ball
  } else {
  // if it does not sense red 
    Intake1.stop();
    Intake2.stop();
    // the intakes will stop rotating
  }
}

void Ball1() {
  Drivetrain.driveFor(forward, 10, inches);
  // the robot moves forward ten inches 
  check();
  // it checks to see if the vision sensor senses a red ball
  // if it does, the intakes will intake the ball
  // if it doesn't the intakes will not move
  Drivetrain.driveFor(forward, 10, inches);
  // the robot will go forward another 10 inches 
  Drivetrain.turnFor(left, 110, degrees);
  // it will turn 110 degrees to the left 
  Drivetrain.driveFor(forward, 30, inches);
  // the robot will drive to the goal, traveling 30 inches to get there 
  Shoot();
  // the ball will be shot into the goal
}

void Ball2() {
  Drivetrain.driveFor(reverse, 20, inches);
  // the robot backs up so that it won't hit the goal when turning
  Drivetrain.turnFor(left, 75, degrees);
  // it turns 75 degress to face the ball
  Drivetrain.driveFor(forward, 20, inches);
  // it drives forward to intake the ball
  check();
  // it checks to see if the vision sensor senses a red ball
  // if it does, the intakes will intake the ball
  // if it doesn't the intakes will not move
}

int main() {
  // Initializing Robot Configuration
  Preset();
  // sets the velocities of the drivetrain and motors, and brings down intakes
  Ball1();
  // intakes the first ball and shoots it 
  Ball2();
  // attmepts to intake the second ball
  vexcodeInit();
}
